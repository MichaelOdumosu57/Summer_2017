whats next

learn how to access the root folder
learn more about tunnelbear
learn more about freshbooks
learn more about synergy
make backups of My_Computer on ubuntu and your usb
