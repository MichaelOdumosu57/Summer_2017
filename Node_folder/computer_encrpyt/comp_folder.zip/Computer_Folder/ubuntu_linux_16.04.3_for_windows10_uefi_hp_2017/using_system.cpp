Keyboard Shortcuts


LAUNCHER
Super(Hold)                 Opens the launcher, display shortcuts
Alt + F1                    Opens the launcher keyboard nav mode
Super + Tab                 Switches applications via the launcher
Super + 1 to 9              Same as clicking on a launcuher icon
Super + Shift + 1 to 9      Opens a new window in the tab
Super + T                   Opens the Trash




HUD & MENU BAR
Alt(Tap)                    Opens HUD
Alt(Hold)                   reveals app menu
Alt + F10                   opens indicator menu
Cursor Left or Right        moves focus btwn indicators
Print                       take a screen shot
Alt + Print                 take a screenshot of current window


SWITCHING
Alt + Tab                   switch btwn apps
Alt + `                     switch btwn windows of current apps
Cursor Left or Right        moves the focus
Cursor Up or Down           enter/ exit from spread mode or select windows
Alt + Q                     closes selected app or window



DASH

Super(Tap)                   opens dash home
Super + A                    opens dash app lens
Super + F                    opens dash file lens
Super + M                    opens dash music lens
Super + C
Super + V
Ctrl + Tab
Arrow Keys
Enter


WINDOWS

Super + W
Ctrl + Super + W
Ctrl + Super + D
Ctrl + Super + Up
Ctrl + Super + Down
Ctrl + Super + Left or Right
Alt + F4
Alt + Space
Ctrl + Alt + Num(keypad)
Alt + Left Mouse Drag
Alt + Middle mouse dra