go to

https://www.easeus.com/todo-backup-resource/how-to-stop-windows-10-from-automatically-update.html
// this is to prevent automatic updates and cause serious problems

https://www.techadvisor.co.uk/how-to/windows/how-back-up-windows-10-3635397/

set up file history
    settings -> Update & security -> Backup